% 3rd order differentiation of a continuous function
function central_difference_example
f=@test_function;
x=-pi:0.1:pi; % differentiation at x=1
h=1e-4; %spacing
n=3; % order of differentiation
% uses central difference function (stored as separate file)
diffn=central_difference(f,x,h,n);
% diffn=richardson_diff(f,x,h,n);
plot(x,diffn,'-r');
hold on;
% analytical differentiation
syms x;
xa=-pi:0.5:pi;
diffa=double(subs(diff(x^2*exp(x),3),x,xa));
plot(xa,diffa,'go');
legend('numerical','anaytical');
xlabel('x');
ylabel('d^3f/dx^3');
return

% test function
function [f] = test_function(x)
f = x.^2.*exp(x);
return