function simple_differentiation
f = @xex;
x=1; h=1e-3;
diff_numerical=central_difference(f,x,h,3)
clear
syms x;
diff_analytical=double(subs(diff(diff(diff(x*exp(x)))),x,1))
return

function [f] = xex(x)
f = x*exp(x);
return
