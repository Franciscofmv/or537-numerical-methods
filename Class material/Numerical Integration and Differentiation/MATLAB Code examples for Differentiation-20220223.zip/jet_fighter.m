% chapra and canale 21.12 (p.541)
function jet_fighter
t = [0 0.52 1.04 1.75 2.37 3.25 3.83];
x = [153 185 210 249 261 271 273];
v = tabular_derivative(t,x);
figure(1);
plot(t,v);
xlabel('time (s)');
ylabel('velocity (m/s)');
a = tabular_derivative(t,v);
figure(2);
plot(t,a);
xlabel('time (s)');
ylabel('acceleration (m/s^2)');
return

function [dydx] = tabular_derivative(x,y)
n = length(x); dydx = zeros(1,n);
% forward difference for first point
dydx(1) = (y(2)-y(1))/(x(2)-x(1));
% central difference for interior points
for i=2:n-1
    dydx(i) = (y(i+1)-y(i-1))/(x(i+1)-x(i-1));
end
% backward difference for last point
dydx(n) = (y(n)-y(n-1))/(x(n)-x(n-1));
return